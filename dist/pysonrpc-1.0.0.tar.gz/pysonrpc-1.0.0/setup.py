from setuptools import setup


# Most of the config is read from setup.cfg
setup()
